//ES6 - function with default paramaters
function sum(a=20,b=5) {
	console.log(a+b);
}

sum(10,2);
sum(10);
sum();
