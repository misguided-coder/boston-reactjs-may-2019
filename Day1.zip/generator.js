//ES6 - generator function
function* uniqueValues() {
	yield 1000;
	yield 2000;
	yield 3000;
	yield 4000;
}

var itr = uniqueValues();

console.log(itr.next().value);
//50 loc
console.log(itr.next().value);
console.log(itr.next().value);
//100 loc
console.log(itr.next().value);

for(var value of uniqueValues()) {
	console.log(value);
}


/*function* generate() {
	for(var idx=0;idx<1000;idx++){
		yield Math.floor(Math.random()*5000);
	}
}*/

function* generate(seed) {
	for(var idx=0;idx<1000;idx++){
		yield Math.floor(Math.random()*seed);
	}
}

var genItr = generate(500);

for(var idx=0;idx<10;idx++){
	console.log(genItr.next().value);
}

function* enjoyCinama() {
	const name = yield "Tell me your name?";
	const age = yield "Tell me your age?";
	return "Hello Mr. "+name+" Your age is : "+age+" ,Enjoy movie";
}

var iterator = enjoyCinama();

console.log(iterator.next());
console.log(iterator.next('Raju'));
console.log(iterator.next(12));
console.log(iterator.next());



//console.log(iterator.next(20));
//console.log(iterator.next(49));
//console.log(iterator.next('Pintu'));

console.log("Finish Line");
