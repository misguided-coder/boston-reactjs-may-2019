class Cal {

	constructor(title) {
		if(arguments.length > 2) {		
			throw new Error('More then 2 arguments not allowed!!!!!');
		}
		console.log("Inside Cal constructor()!!!!!");
		//this.title = 'Simple Calculator';
		this.title = title;
	}

	doSum(a,b) {
		console.log(a+b);
	}		

	doDiff(a,b) {
		console.log(a-b);
	}		
}

var cal1 = new Cal('Calculator A',3,7);
var cal2 = new Cal('Calculator B',3);

cal1.doSum(10,2);
cal1.doDiff(10,2);

//cal1.title = 'Very Simple Calculator';
//cal2.title = 'Easy Calculator';

console.log(cal1.title);
console.log(cal2.title);

//console.log(typeof cal);
//console.log(cal instanceof Cal);

