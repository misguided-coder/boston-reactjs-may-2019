var ref = require('./math.js');
console.log("Main Module!!!!");


console.log(ref.title);
ref.sum(10,2);
ref.diff(40,2);

let math= new ref.Math();
math.multiply(10,2);