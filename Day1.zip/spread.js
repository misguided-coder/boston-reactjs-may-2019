
var array = [34,56,23,12,32];
console.log(array.length);
console.log(array);

//ES5
var i = array[0];
var j = array[1];
var k = array[2];
var l = array[3];
var m = array[4];
console.log(j);
console.log(m);

//ES6 - spread operator
console.log(...array);
var [a,b,c,d,e] = [...array];
console.log(b);
console.log(e);

//ES5
function showValues(array) {
	console.log("Array Length is : "+array.length);
	console.log("Array Data is : "+array);
}

showValues([3,4,1,2,6,7,8,9]);

//ES6
function showNumbers(...array) {
	console.log("Array Length is : "+array.length);
	console.log("Array Data is : "+array);
}

showNumbers(3,4,1,2,6,7,8,9);




