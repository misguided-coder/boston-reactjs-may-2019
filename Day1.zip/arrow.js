greet('Jaggu');

//function declaration (hoisting)
function greet(name) {
	console.log("Good Afternoon : "+name);
}

greet('Bill Gates');


//function expression (no hoisting)
var a = function (name) {
	console.log("Good Noon : "+name);
}

a('Raj');

//ES6 --- fat arrow function
var b = (name) => {
	console.log("Good Morning : "+name);
}

b('Mohan');

/*function generate(value) {
	return 1000 * value; 
}*/


var generate = function (value) {
	return 1000 * value; 
}

var rs = generate(5);

console.log(rs);

/*var gen = (value) => {
	return 1000 * value; 
}*/

//var gen = (value) => { return 1000 * value; }

//var gen = (value) => 1000 * value;

var gen = value => 1000 * value;

var rs = gen(2);

console.log(rs);

/*var cool = () => {
	 console.log("Today is cool day"); 
}*/

var cool = () => console.log("Today is cool day");

cool();


//IIFE - Immediately Invokable Function Expression
//Self Invoking Function
(function () {
	 console.log("Hello ji"); 
})();

var check = new Function('age',"console.log('Your age is : '+age)");
check(12);


