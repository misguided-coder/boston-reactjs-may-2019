var i = 10;
console.log(i);

function sum(a,b) {
	console.log(a+b);
}

sum(2,2);