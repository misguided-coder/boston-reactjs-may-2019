class Furniture {

	constructor() {
		this._material = "Wood";		
	}

	info() {
		console.log("It is all about cool looking furnitures!!!!!");
	}

	get material() {
		console.log("Inside getMaterial()!!!!!");
		return this._material;
	}

	set material(material) {
		console.log("Inside setMaterial(material)!!!!!");
		this._material = material;
	}
}

class Chair extends Furniture {
	
	constructor() {
		super();
		this.type = "Relaxing";		
	}
	
	info() {
		super.info();
		console.log("Chair Type : "+this.type);
	}

}

var chair = new Chair();

//console.log(chair.getMaterial());
//chair.setMaterial('Plastic');
//console.log(chair.getMaterial());

console.log(chair.material);
chair.material = 'Plastic';
console.log(chair.material);

chair.info();
