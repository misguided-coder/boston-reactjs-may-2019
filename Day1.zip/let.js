i = 10
console.log(i);
console.log(typeof i);

i = "Raj";
console.log(i);
console.log(typeof i);


let j = 10;
console.log(j);

const k = 10;
console.log(k);


var age = 25;

function doWork() {
	var age = 35;
	console.log(age);
}

doWork();

console.log(age);


var title = "ES6 is cool";

//block
{
	//no-block scope
	var title = "ES6 is amazing";
	console.log(title);
}

console.log(title);

if(true) {
	let name = "Jaggu";
	console.log(name);
	name = name + " Singh";
	console.log(name);
}

//console.log(name);

for(var i=0;i<10;i++){
	console.log("Good Morning......");
}

console.log(i);

function fun() {
	var partyTime = "8 PM";
	console.log(partyTime);
	
	//no-block scope
	if(true) {
		var partyTime = "10 PM";
		console.log(partyTime);
	}

	console.log(partyTime);
}

fun();

fun.AUTHOR = "Ritesh Tyagi";

console.log(fun.AUTHOR);

var sum = new Function('a','b','console.log(a+b);');

sum(10,2);
sum.day = 'Monday';
console.log(sum.day);


function timer() {
	time = "8 PM"
	console.log(time);
	
	for(var i=0;i<10;i++){
		console.log("Good Morning......");
	}

	console.log(i);
}

timer();

console.log(time)




