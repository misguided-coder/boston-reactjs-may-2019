//call back function
function greet(name) {
	console.log("Hello : "+name);
}

function greetMe(name) {
	console.log("Hi : "+name);
}

function greetYou(name) {
	console.log("Bye : "+name);
}

function greetOther(name) {
	console.log("Bye Bye: "+name);
}


//Developer A
function showNames(fn) {
	console.log(typeof fn);
	console.log("Preparing for showing names");
	console.log("Prepared for showing names");
	var names = ['Raju','Pintu','Jaggu','Ghanshu'];
	
	for(var idx=0;idx<names.length;idx++) {
		fn(names[idx]); //call back function
	}
	
	console.log("Done");
}



//Developer B
showNames(greet);
showNames(greetMe);
showNames(greetYou);
showNames(greetOther);

showNames(function (name) { //inline function
	console.log("Go and Bye: "+name);
});

showNames(function (name) { //inline function
	console.log("Will call You : "+name);
});

showNames(function (name) { //inline function
	console.log("Will not call You : "+name);
});

showNames((name) => { //inline function
	console.log("Will never call You : "+name);
});


