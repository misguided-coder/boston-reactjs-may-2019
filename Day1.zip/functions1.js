function greet(name) {
	console.log("Hello : "+name);
}

//Developer A
function showNames() {
	console.log("Preparing for showing names");
	console.log("Prepared for showing names");
	var names = ['Raju','Pintu','Jaggu','Ghanshu'];
	
	for(var idx=0;idx<names.length;idx++) {
		greet(names[idx]);
	}
	
	console.log("Done");
}


//Developer B
showNames();