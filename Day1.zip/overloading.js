function sum(a,b,c) {
	console.log("Inside sum(a,b,c)!!!");
	console.log(a+b+c);
}

function sum(a,b) {
	var total = 0;
	console.log("Length : "+arguments.length);
	console.log("Inside sum(a,b)!!!");
	for(let val of arguments){
		total += val;
	}
	console.log("SUM : "+total);
}


//ES6
function sum(...args) {
	var total = 0;
	console.log("Length : "+args.length);
	console.log("Inside sum(a,b)!!!");
	for(let val of args){
		total += val;
	}
	console.log("SUM : "+total);
}


sum(2,5);
sum(2,5,8);
sum(12,2,5,8);
sum(1,12,2,5,8);
