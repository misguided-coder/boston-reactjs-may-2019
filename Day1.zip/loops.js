var array = [34,56,23,12,32];
console.log(array.length);
console.log(array);

console.log(array[0]);

for(var idx=0;idx<array.length;idx++){
	console.log(array[idx] * 2);
}

console.log("=================");

for(var val in array){
	console.log(val);
	console.log(array[val]);
}

console.log("=================");


//ES6
for(var val of array){
	console.log(val);
}

console.log("=================");


var data = {city:'Delhi',min:20,max:45,humidity:90};

console.log(data.city);
console.log(data.min);
console.log(data.max);
console.log(data.humidity);

for(var k in data){
	console.log(k);
	console.log(data[k]);
}

console.log("=================");





