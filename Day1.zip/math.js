let title = "Math Calculator";

class Math {
	multiply(a,b) {
		console.log(a*b);
	}
}

function sum(a,b) {
	console.log(a+b);
}

function diff(a,b) {
	console.log(a+b);
}

exports.title = title;
exports.Math = Math;
exports.sum = sum;
exports.diff = diff;
